# PDV - Nível 1

Script feito em Python para simular um fluxo de caixa/ponto de venda simples no terminal. Ele registra vendas consecutivas, calcula descontos progressivos com base na idade do cliente e no valor da compra, e gera um fechamento com o resumo do dia assim que o caixa é encerrado.

## Como funciona o fluxo

**Entrada de dados:** O programa pede o valor da compra e a idade do comprador, validando para não aceitar números negativos nem entradas vazias.
**Desconto de idade:** Se o cliente tiver 65 anos ou mais, aplica 20% de desconto sobre o valor inicial.
**Desconto por volume:** Se o valor após o primeiro desconto ainda for maior que R$ 100.00, aplica mais 10% de desconto cumulativo sobre esse saldo restante.
**Armazenamento:** O valor final a pagar é exibido na tela e os dados da venda vão para uma lista de registros via .append().
**Loop e encerramento:** As vendas continuam sendo registradas até que o usuário digite "0" no valor da compra.
**Fechamento:** Ao parar, o script puxa os dados da lista e imprime o total de pedidos, valor bruto, soma dos descontos dados e o faturamento líquido.

## Como rodar
Com o terminal aberto dentro da pasta nivel_1, execute: python pdv.py

## Tabela de exemplos
| # | Valor (R$) | Idade | Desconto idade | Desconto valor | Valor final esperado |
|---|---|---|---|---|---|
| 1 | 50.00 | 30 | 0% | 0% | R$ 50.00 |
| 2 | 100.00 | 30 | 0% | 0% | R$ 100.00 |
| 3 | 80.00 | 65 | 20% | 0% | R$ 64.00 |
| 4 | 100.00 | 70 | 20% | 0% | R$ 80.00 |
| 5 | 125.00 | 70 | 20% | 0% | R$ 100.00 |
| 6 | 200.00 | 30 | 0% | 10% | R$ 180.00 |
| 7 | 101.00 | 30 | 0% | 10% | R$ 90.90 |
| 8 | 200.00 | 65 | 20% | 10% | R$ 144.00 |
| 9 | 1000.00 | 80 | 20% | 10% | R$ 720.00 |
| 10 | 200.00 | 64 | 0% | 10% | R$ 180.00 |