compras = []
while True:
    while True:
        try:
            valor = float(input("\nInforme o valor da compra em R$ (ou 0 para encerrar): "))
            if valor < 0:
                print("Valor inválido! O valor não pode ser negativo. Tente novamente.")
                continue
            break
        except ValueError:
            print("Entrada inválida! Digite um número válido.")
    if valor == 0:
        break
    while True:
        try:
            idade = int(input("Informe a idade do cliente: "))
            if idade < 0:
                print("Idade inválida! A idade não pode ser negativa. Tente novamente.")
                continue
            break
        except ValueError:
            print("Entrada inválida! Digite um número inteiro.")

    valor_com_desconto_idade = valor
    if idade >= 65:
        valor_com_desconto_idade = valor * 0.80
    valor_final = valor_com_desconto_idade
    if valor_com_desconto_idade > 100:
        valor_final = valor_com_desconto_idade * 0.90

    print(f"Valor final a pagar: R$ {valor_final:.2f}")

    desconto_total = valor - valor_final
    compras.append({
        "bruto": valor,
        "desconto": desconto_total,
        "final": valor_final
    })

print("\n" + "=" * 35)
print("          RESUMO DO DIA          ")
print("=" * 35)

total_bruto = sum(item["bruto"] for item in compras)
total_descontos = sum(item["desconto"] for item in compras)
total_final = sum(item["final"] for item in compras)
qtd_compras = len(compras)

print(f"Quantidade de compras registradas: {qtd_compras}")
print(f"Total bruto:                       R$ {total_bruto:.2f}")
print(f"Total de descontos concedidos:     R$ {total_descontos:.2f}")
print(f"Total final:                       R$ {total_final:.2f}")
print("=" * 35)